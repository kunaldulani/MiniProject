

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "approved_loans")
public class ApprovedLoans 
{
	
	@OneToOne(cascade=CascadeType.PERSIST, fetch=FetchType.LAZY)
	@JoinColumn(name="applicationId")
	private int applicationId;
	
	@Column(length=20)
	private String customerNameString;
	 private int amountOfLoanGranted;
	 private int monthlyInstallment;
	 private int yearsTimePeriod;
	 private int downPayement;
	 private int rateOfInterest;
	 private int totalAmountPayable;
	 
	public ApprovedLoans()
	{
		super();
	}

	public ApprovedLoans(int applicationId, String customerNameString,
			int amountOfLoanGranted, int monthlyInstallment,
			int yearsTimePeriod, int downPayement, int rateOfInterest,
			int totalAmountPayable) {
		super();
		this.applicationId = applicationId;
		this.customerNameString = customerNameString;
		this.amountOfLoanGranted = amountOfLoanGranted;
		this.monthlyInstallment = monthlyInstallment;
		this.yearsTimePeriod = yearsTimePeriod;
		this.downPayement = downPayement;
		this.rateOfInterest = rateOfInterest;
		this.totalAmountPayable = totalAmountPayable;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getCustomerNameString() {
		return customerNameString;
	}

	public void setCustomerNameString(String customerNameString) {
		this.customerNameString = customerNameString;
	}

	public int getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}

	public void setAmountOfLoanGranted(int amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}

	public int getMonthlyInstallment() {
		return monthlyInstallment;
	}

	public void setMonthlyInstallment(int monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}

	public int getYearsTimePeriod() {
		return yearsTimePeriod;
	}

	public void setYearsTimePeriod(int yearsTimePeriod) {
		this.yearsTimePeriod = yearsTimePeriod;
	}

	public int getDownPayement() {
		return downPayement;
	}

	public void setDownPayement(int downPayement) {
		this.downPayement = downPayement;
	}

	public int getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public int getTotalAmountPayable() {
		return totalAmountPayable;
	}

	public void setTotalAmountPayable(int totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}

	@Override
	public String toString() {
		return "ApprovedLoans [applicationId=" + applicationId
				+ ", customerNameString=" + customerNameString
				+ ", amountOfLoanGranted=" + amountOfLoanGranted
				+ ", monthlyInstallment=" + monthlyInstallment
				+ ", yearsTimePeriod=" + yearsTimePeriod + ", downPayement="
				+ downPayement + ", rateOfInterest=" + rateOfInterest
				+ ", totalAmountPayable=" + totalAmountPayable + "]";
	}
	 
	
	 
}

